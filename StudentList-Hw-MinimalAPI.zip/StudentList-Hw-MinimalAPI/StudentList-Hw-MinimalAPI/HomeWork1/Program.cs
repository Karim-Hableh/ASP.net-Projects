
using Microsoft.AspNetCore.Mvc;
using System.Security.Cryptography.X509Certificates;

namespace HomeWork1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddAuthorization();

            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            var studentGroup = app.MapGroup("/student/{id}").AddEndpointFilter(ValidateId.InvokeAsync);

            var studentBody = app.MapGroup("/student/{id}")
                .AddEndpointFilter(ValidateId.InvokeAsync)
                .AddEndpointFilter<ValidateGrade>();

            app.MapGet("/student", Handlers.GetAllStudents);
            studentGroup.MapGet("/", (int id) => Handlers.GetStudentById(id));
            studentBody.MapPost("/", (int id, Student student) => Handlers.AddStudent(id, student));
            studentBody.MapPut("/", (int id, Student student) => Handlers.UpdateStudent(id, student));
            studentGroup.MapDelete("/", (int id) => Handlers.DeleteStudent(id));
            app.MapGet("/student/average", Handlers.GetAverage);
            app.MapGet("/student/info", Handlers.GetStudentsInfo);

            app.UseHttpsRedirection();

            app.UseAuthorization();
            app.Run();
        }
    }
    public record StudentList
    {
        public static Dictionary<int, Student> Students = new();
    }
    public class Student
    {
        public string Name { get; set; } = string.Empty;
        public int Age { get; set; }
        public string Nationality { get; set; } = string.Empty;
        public double Grade { get; set; }
    }

    public class Handlers
    {
        public static IResult GetAllStudents()
        {
            return Results.Ok(StudentList.Students);
        }
        public static IResult GetStudentById(int id)
        {
            bool exists = StudentList.Students.TryGetValue(id, out var student);
            if(!exists)
            {
                // student not found
                return Results.ValidationProblem(new Dictionary<string, string[]>
                {
                    {"Id", new [] {"Student with this id does not exist"} }
                });
            }
            // student with passed id is found
            return Results.Ok(student);
        }
        public static IResult AddStudent(int id, Student student)
        {
            if(StudentList.Students.ContainsKey(id))
            {
                return Results.ValidationProblem(new Dictionary<string, string[]>
                {
                    {"Id", new [] {"Student with this id already exists"} }
                });
            }
            StudentList.Students.Add(id, student);
            return Results.Created($"/student/{id}", student);
        }
        public static IResult UpdateStudent(int id, Student student)
        {
            if (!StudentList.Students.ContainsKey(id))
            {
                return Results.ValidationProblem(new Dictionary<string, string[]>
                {
                    {"Id", new [] {"Student with this id does not exist"} }
                });
            }
            StudentList.Students[id] = student;
            return Results.Ok(student);
        }
        public static IResult DeleteStudent(int id)
        {
            if (!StudentList.Students.ContainsKey(id))
            {
                return Results.ValidationProblem(new Dictionary<string, string[]>
                {
                    {"Id", new [] {"Student with this id does not exist"} }
                });
            }
            StudentList.Students.Remove(id);
            return Results.Ok("Student was deleted successfully");
        }
        public static IResult GetAverage()
        {
            if(StudentList.Students.Count > 0)
            {
                return Results.Ok(StudentList.Students.Average(s => s.Value.Grade));
            }
            return Results.Ok("No Students in the Dictionary");
        }
        public static IResult GetStudentsInfo()
        {
            return Results.Ok(StudentList.Students.Select(s => new { Id = s.Key, Name = s.Value.Name, Nationality = s.Value.Nationality}).ToList());
        }

    }
    class ValidateId
    {
        public async static ValueTask<object?> InvokeAsync(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
        {
            var id = context.GetArgument<int>(0);
            if(id < 0 || id >= 1000)
            {
                return Results.ValidationProblem(new Dictionary<string, string[]>
                {
                    {"Id", new [] {"Id should be between 0 and 1000"} }
                });
            }
            return await next(context);
        }
    }
    class ValidateGrade : IEndpointFilter
    {
        public async ValueTask<object?> InvokeAsync(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
        {
            var student = context.GetArgument<Student>(1);
            if(student.Grade < 0 || student.Grade > 100)
            {
                return Results.ValidationProblem(new Dictionary<string, string[]>
                {
                    {"Grade", new [] {"Grade should be between 0 and 100"} }
                });
            }
            return await next(context);
        }
    }
}