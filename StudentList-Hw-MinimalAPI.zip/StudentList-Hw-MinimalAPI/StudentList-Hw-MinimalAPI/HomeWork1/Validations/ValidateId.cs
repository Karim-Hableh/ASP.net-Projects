﻿namespace HomeWork1.Validations
{
	public class ValidateId
	{
	}
}
