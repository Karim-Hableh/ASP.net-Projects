﻿namespace HomeWork1.Validations
{
	public class ValidateGrade
	{
	}
}
