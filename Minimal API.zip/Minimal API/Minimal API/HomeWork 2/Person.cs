﻿namespace HomeWork_2
{
	public class Person
	{
	}
}
