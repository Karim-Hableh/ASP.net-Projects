using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();


app.MapGet("/api/random-a", Handlers.RandomInt);
app.MapGet("/api/random-b", Handlers.RandomIntQuery);
app.MapGet("/api/square-b", Handlers.GetSquare);
app.MapPost("/api/person-a", Handlers.AddPerson).AddEndpointFilter<ValidatePerson>();
app.MapPost("/api/persons", Handlers.AddPeople).AddEndpointFilter<ValidatePeople>();
app.MapGet("/api/person/{id}", Handlers.GetPerson);
app.MapGet("/api/user-a", Handlers.GetUser);
app.MapGet("/api/user-b", Handlers.GetFilteredUsers);
app.MapPost("/api/user", Handlers.AddUser)
    .WithParameterValidation();
app.MapGet("/api/users", Handlers.GetUsersOlder)
    .AddEndpointFilter<ValidateAge>();
app.MapGet("/api/users/{username}", Handlers.GetUsersByUsername);
app.MapPost("/api/user/{username}", Handlers.UpdateEmail);
app.MapPost("/api/products", Handlers.AddProduct).WithParameterValidation();
app.MapGet("/api/products", Handlers.GetProductsWithinRange)
    .AddEndpointFilter<ValidatePrices>();
app.MapGet("/api/products/{title}", Handlers.GetProductsByTitleAndDescription);
app.MapPost("/api/products/{title}/{description}", Handlers.AddProductTryParse);
app.MapGet("/api/person/{id}/{name}", Handlers.GetPersonWithIdAndName);
app.MapGet("/api/person/bindasync/{id?}/{name?}", Handlers.PersonBindAsync);


app.Run();

class Handlers
{
    static List<Person> people = new List<Person>
    {
        new Person { Id = 1, Name = "Alice", DateOfBirth = DateTime.UtcNow },
        new Person { Id = 2, Name = "Bob", DateOfBirth = new DateTime(1985, 10, 25) },
        new Person { Id = 3, Name = "Charlie", DateOfBirth = new DateTime(1988, 3, 8) }
    };

    // Collection of User objects
    static List<User> users = new List<User>
    {
        new User { Username = "user1", Email = "user1@gmail.com", Age = 30 },
        new User { Username = "user2", Email = "user2@ul.edu.lb", Age = 25 },
        new User { Username = "user3", Email = "user3@gmail.com", Age = 35 }
    };

    // Collection of Product objects
    static List<Product> products = new List<Product>
    {
        new Product { Title = "Product 1", Description = "Description of Product 1", Price = 99.99 },
        new Product { Title = "Product 2", Description = "Description of Product 2", Price = 149.99 },
        new Product { Title = "Product 3", Description = "Description of Product 3", Price = 199.99 }
    };

    public static IResult RandomInt()
    {
        var random = new Random();
        var number = random.Next(1, 100);
        return Results.Ok(number);
    }
    public static IResult RandomIntQuery(int count = 1)
    {
        List<int> ints = new List<int>();
        var random = new Random();
        for (int i = 1; i <= count; i++)
        {
            var number = random.Next(1, 100);
            ints.Add(number);
        }
        return Results.Ok(ints);
    }
    public static IResult GetSquare([FromQuery(Name = "id")] int[] ids)
    {
        return Results.Ok(ids.Select(x => x * x));
    }
    public static IResult AddPerson([FromBody] Person person, ILogger<Program> logger)
    {
        logger.LogInformation($"Adding person with name: {person.Name}");
        people.Add(person);
        return Results.Ok(person);
    }
    public static IResult AddPeople(Person[] persons)
    {
        people.AddRange(persons);
        return Results.Ok(persons);
    }
    public static IResult GetPerson(int id)
    {
        var person = people.FirstOrDefault(x => x.Id == id);
        if(person is null)
        {
            return Results.NotFound("Person with this id does not exist");
        }
        return Results.Ok(person);
    }
    public static IResult GetUser()
    {
        var user = new User
        {
            Username = "Hasan",
            Email = "hasan@gmail.com",
            Age = 30
        };
        return Results.Ok(user);
    }
    public static IResult GetFilteredUsers(int? age, string? username)
    {
        if(age is null && username is null)
        {
            return Results.Ok(users);
        }
        return Results.Ok(users.Where(x => x.Age == age || x.Username == username).ToList());
    }
    public static IResult AddUser(User user)
    {
        users.Add(user);
        return Results.Ok(user);
    }
    public static IResult GetUsersOlder(int age)
    {
        return Results.Ok(users.Where(u => u.Age > age).ToList());
    }
    public static IResult GetUsersByUsername(string username)
    {
        if (username.Length > 20)
            return Results.ValidationProblem(new Dictionary<string, string[]>
            {
                {"username", new [] {"username should be less than 20 characters"} }
            });
        var usersByUsername = users.Where(u => u.Username.Equals(username)).ToList();
        if (usersByUsername.Count == 0)
            return Results.NotFound("No user with given username");
        return Results.Ok(usersByUsername);
    }
    public static IResult UpdateEmail(string username, [FromBody] string email)
    {
        var user = users.FirstOrDefault(x => x.Username == username);
        if(user is null)
        {
            return Results.NotFound("No user with given username");
        }
        user.Email = email;
        return Results.Ok("Email has been updated");
    }
    public static IResult AddProduct([FromBody]Product product)
    {
        products.Add(product);
        return Results.Ok(product);
    }
    public static IResult GetProductsWithinRange(double min, double max)
    {
        var productsInRange = products.Where(p => p.Price >= min && p.Price <= max).ToList();
        if(productsInRange.Count == 0)
        {
            return Results.NotFound("No products in this price range");
        }
        return Results.Ok(productsInRange);
    }
    public static IResult GetProductsByTitleAndDescription(string title, string description)
    {
        if(string.IsNullOrEmpty(title) || string.IsNullOrEmpty(description))
        {
            return Results.ValidationProblem(new Dictionary<string, string[]>
            {
                {"Title", new[] {"Title should not be empty"} },
                {"Description", new[] {"description should not be empty"} }
            });
        }
        var products2 = products.Where(p => p.Title.Contains(title) || p.Description.Contains(description)).ToList();
        return Results.Ok(products2);
    }
    public static IResult AddProductTryParse(string title, string description, Product? product)
    {
        if(product is null)
        {
            product = new Product
            {
                Price = 1
            };
        }
        product.Title = title;
        product.Description = description;
        products.Add(product);
        return Results.Ok(product);
    }
    public static IResult GetPersonWithIdAndName([AsParameters] Person person)
    {
        var person2 = people.FirstOrDefault(p => p.Id == person.Id && p.Name == person.Name);
        if(person2 is null)
        {
            return Results.NotFound("No person with such id and name exists");
        }
        return Results.Ok(person);
    }
    public static IResult PersonBindAsync(Person person)
    {
        return Results.Ok(people.Where(p => p.Id == person.Id || p.Name == person.Name).ToList());
    }
}

public class Person
{
    public int Id { get; set; }
    public string Name { get; set; }
    public DateTime? DateOfBirth { get; set; }
    public static async ValueTask<Person?> BindAsync(HttpContext context)
    {
        var person = new Person();
        var routeParams = context.Request.RouteValues;
        var queryStrings = context.Request.Query;
        if(routeParams.TryGetValue("id", out var id))
        {
            if(int.TryParse(id.ToString(),out var intId))
            {
                person.Id = intId;
            }
        }
        else if(queryStrings.TryGetValue("id", out var queryId))
        {
			if (int.TryParse(queryId.ToString(), out var intQueryId))
			{
				person.Id = intQueryId;
			}
		}
		if (routeParams.TryGetValue("name", out var name))
		{
            person.Name = name.ToString();
		}
		else if (queryStrings.TryGetValue("name", out var queryName))
		{
            person.Name = queryName;
		}
		return person;
    }
}

public class User : IValidatableObject
{
    [StringLength(20)]
    public string Username { get; set; }
    public string Email { get; set; }
    [Range(1, 100)]
    public int Age { get; set; }

	public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
	{
        if(Age % 2 != 0)
        {
            yield return new ValidationResult("Age must be a multiple of 2", new[] {nameof(Age)});
        }
        if(!Email.Contains("gmail.com") && !Email.Contains("ul.edu.lb"))
        {
            yield return new ValidationResult("Email must contain either gmail.com or ul.edu.lb", new[] { nameof(Email) }); ;
		}
	}
}
public class Product
{
    [Required]
    public string Title { get; set; }
    [Required]
    public string Description { get; set; }
    [Required]
    public double Price { get; set; }
    public static bool TryParse(string? s, out Product result)
    {
        if(s is not null && double.TryParse(s, out var price))
        {
            result = new Product
            {
                Price = price
            };
            return true;
        }
        result = default;
        return false;
    }
}

class ValidatePerson : IEndpointFilter
{
    public async ValueTask<object?> InvokeAsync(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
    {
        var person = context.GetArgument<Person>(0);
        if (person.Id < 1 || person.Id > 1000)
        {
            return Results.ValidationProblem(new Dictionary<string, string[]>
            {
                {"Id", new[] {"Id should be between 1 and 1000"} }
            });
        }
        if (!char.IsLetter(person.Name.FirstOrDefault()))
        {
            return Results.ValidationProblem(new Dictionary<string, string[]>
            {
                {"Name", new[] {"Name should start with a letter"} }
            });
        }
        return await next(context);
    }
}
class ValidatePeople : IEndpointFilter
{
    public async ValueTask<object?> InvokeAsync(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
    {
        var people = context.GetArgument<Person[]>(0);
        var check = people.All(x => x.Id >= 1 && x.Id <= 1000 && char.IsLetter(x.Name.FirstOrDefault()));
        if(check)
        {
            return await next(context);
        }
        return Results.ValidationProblem(new Dictionary<string, string[]>
        {
            {"Id", new [] {"Id should be between 1 and 1000"} },
            {"Name", new[] {"Name should start with a letter"} }
        });
        /*foreach(var person in people)
        {
            if (person.Id < 1 || person.Id > 1000)
            {
                return Results.ValidationProblem(new Dictionary<string, string[]>
            {
                {"Id", new[] {"Id should be between 1 and 1000"} }
            });
            }
            if (!Char.IsLetter(person.Name.FirstOrDefault()))
            {
                return Results.ValidationProblem(new Dictionary<string, string[]>
            {
                {"Name", new[] {"Name should start with a letter"} }
            });
            }
        }*/
    }
}

class ValidateAge : IEndpointFilter
{
	public async ValueTask<object?> InvokeAsync(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
	{
        var age = context.GetArgument<int>(0);
        if(age < 1 || age > 100)
        {
            return Results.ValidationProblem(new Dictionary<string, string[]>
            {
                {"age", new[] {"Age should be between 1 and 100"} }
            });
        }
        return await next(context);
	}
}

class ValidatePrices : IEndpointFilter
{
	public async ValueTask<object?> InvokeAsync(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
	{
        var minPrice = context.GetArgument<double>(0);
        var maxPrice = context.GetArgument<double>(1);
        if(minPrice < 0 || maxPrice < 0 || minPrice >= maxPrice)
        {
            return Results.ValidationProblem(new Dictionary<string, string[]>
            {
                {"minPrice", new [] {"min price shoud be positive and less than max price"} },
                {"maxPrice", new[] {"max price should be positive"} }
            });
        }
        return await next(context);
	}
}