﻿namespace HomeWork_3.Requests
{
	public record CategoryRequest	
	{
		public string Name { get; set; }
	}
}
