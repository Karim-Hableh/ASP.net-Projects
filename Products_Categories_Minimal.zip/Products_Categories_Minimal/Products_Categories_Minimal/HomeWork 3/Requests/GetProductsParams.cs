﻿namespace HomeWork_3.Requests
{
	public class GetProductsParams
	{
		public decimal? MinPrice { get; set; }
		public decimal? MaxPrice { get; set; }
		public string? ProductName { get; set; }
		public string? ProductDescription { get; set; }
		public int? CategoryId { get; set; }
	}
}
