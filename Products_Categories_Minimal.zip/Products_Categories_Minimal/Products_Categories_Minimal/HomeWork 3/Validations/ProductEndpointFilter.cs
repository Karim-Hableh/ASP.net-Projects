﻿
using HomeWork_3.Data;
using HomeWork_3.Requests;
using Microsoft.EntityFrameworkCore;

namespace HomeWork_3.Validations
{
	public class ProductEndpointFilter : IEndpointFilter
	{
		public async ValueTask<object?> InvokeAsync(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
		{
			var request = context.GetArgument<ProductRequest>(1);
			var dbContext = context.HttpContext.RequestServices.GetRequiredService<DataContext>();
			var category = await dbContext.Categories.FirstOrDefaultAsync(c => c.Id == request.CategoryId);
            if (category is null)
            {
				return Results.ValidationProblem(new Dictionary<string, string[]>
				{
					{"CategoryId", new[] {"No Category with provided id exists"} }
				});
            }
			if(string.IsNullOrEmpty(request.Name))
			{
				return Results.ValidationProblem(new Dictionary<string, string[]>
				{
					{"Name", new[] {"Name is required"} }
				});
			}
			return await next(context);
        }
	}
}
