﻿using HomeWork_3.Models;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace HomeWork_3.Data
{
	public class DataContext : DbContext
	{
        public DataContext(DbContextOptions options) : base(options)
        {
            
        }
        public DbSet<Product> Products { get; set; }
		public DbSet<Category> Categories { get; set; }
	}
}
