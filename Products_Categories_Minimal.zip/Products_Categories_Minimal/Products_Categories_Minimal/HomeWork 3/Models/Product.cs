﻿using HomeWork_3.Requests;

namespace HomeWork_3.Models
{
	public class Product
	{
		// auto increment by default since type is integer.
		public int Id { get; set; }
		public string Name { get; set; }
		public string? Description { get; set; }
		public decimal Price { get; set; }
		public int CategoryId { get; set; }
		// Navigation Property
		public Category Category { get; set; }
		public void Update(ProductRequest request)
		{
			Name = request.Name;
			Description = request.Description;
			Price = request.Price;
			CategoryId = request.CategoryId;
		}
	}
}
