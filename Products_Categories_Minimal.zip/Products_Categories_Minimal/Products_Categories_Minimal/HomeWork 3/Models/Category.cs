﻿using HomeWork_3.Requests;

namespace HomeWork_3.Models
{
	public class Category
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public void Update(CategoryRequest request)
		{
			Name = request.Name;
		}
	}
}
