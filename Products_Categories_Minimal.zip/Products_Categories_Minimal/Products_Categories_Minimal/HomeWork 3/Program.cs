using HomeWork_3.Data;
using HomeWork_3.Requests;
using HomeWork_3.Services.Implementations;
using HomeWork_3.Services.Interfaces;
using HomeWork_3.Validations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<DataContext>(opt =>
{
	opt.UseSqlServer(builder.Configuration.GetConnectionString("EcommerceConnection"));
});
builder.Services.AddScoped<IProductService, ProductService>();
builder.Services.AddScoped<ICategoryService,CategoryService>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
	app.UseSwagger();
	app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.MapGet("/products", (IProductService service, [AsParameters] GetProductsParams input) => service.GetAllProducts(input));
app.MapPost("/products", (IProductService service, [FromBody] ProductRequest request) => service.AddProduct(request))
	.AddEndpointFilter<ProductEndpointFilter>();
app.MapGet("/products/average", (IProductService service) => service.GetAverage());


app.MapPost("/categories", (ICategoryService service, [FromBody] CategoryRequest request) => service.AddCategory(request));
app.MapGet("/categories", (ICategoryService service) => service.GetAllCategories());
app.MapGet("/categories/{id}", (ICategoryService service, int id) => service.GetCategoryById(id));
app.MapPut("/categories/{id}", (ICategoryService service, [FromBody] CategoryRequest request, int id) => service.UpdateCategory(id, request));
app.MapDelete("/categories/{id}", (ICategoryService service, int id) => service.DeleteCategory(id));
app.MapGet("/categories/count/{id}", (ICategoryService service, int id) => service.GetProductCount(id));


app.Run();

