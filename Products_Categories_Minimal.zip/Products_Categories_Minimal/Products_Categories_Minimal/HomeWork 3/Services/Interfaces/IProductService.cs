﻿using HomeWork_3.Models;
using HomeWork_3.Requests;

namespace HomeWork_3.Services.Interfaces
{
	public interface IProductService
	{
		public Task<IResult> GetAllProducts(GetProductsParams input);
		public Task<IResult> GetProductById(int id);
		public Task<IResult> DeleteProduct(int id);
		public Task<IResult> AddProduct(ProductRequest request);
		public Task<IResult> UpdateProduct(int id, ProductRequest request);
		public IResult GetAverage();
	}
}
