﻿using HomeWork_3.Requests;

namespace HomeWork_3.Services.Interfaces
{
	public interface ICategoryService
	{
		public Task<IResult> GetAllCategories();
		public Task<IResult> GetCategoryById(int id);
		public Task<IResult> DeleteCategory(int id);
		public Task<IResult> AddCategory(CategoryRequest request);
		public Task<IResult> UpdateCategory(int id, CategoryRequest request);
		public Task<IResult> GetProductCount(int id);
	}
}
