﻿using HomeWork_3.Data;
using HomeWork_3.Models;
using HomeWork_3.Requests;
using HomeWork_3.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace HomeWork_3.Services.Implementations
{
	public class CategoryService : ICategoryService
	{
		private readonly DataContext context;
        public CategoryService(DataContext context)
        {
			this.context = context;
        }
        public async Task<IResult> AddCategory(CategoryRequest request)
		{
			var category = new Category
			{
				Name = request.Name
			};
			context.Add(category);
			await context.SaveChangesAsync();
			return Results.Ok(category);
	}

		public async Task<IResult> DeleteCategory(int id)
		{
			var category = await context.Categories.FirstOrDefaultAsync(c => c.Id == id);
			if(category is null)
			{
				return Results.NotFound("No category with this id");
			}
			context.Remove(category);
			await context.SaveChangesAsync();
			return Results.Ok("Category was deleted successfully");
		}

		public async Task<IResult> GetAllCategories()
		{
			var categories = await context.Categories.ToListAsync();
			return Results.Ok(categories);
		}

		public async Task<IResult> GetCategoryById(int id)
		{
			var category = await context.Categories.FirstOrDefaultAsync(c => c.Id == id);
			if(category is null)
				return Results.NotFound("No category with this id");
			return Results.Ok(category);
		}

		public async Task<IResult> GetProductCount(int id)
		{
			var category = await context.Categories
				.Select(c => new
				{
					c.Id,
					c.Name,
					ProductCount = context.Products.Count(p => p.CategoryId == id)
				})
				.FirstOrDefaultAsync(c => c.Id == id);
			if (category is null)
				return Results.NotFound("No category with this id exists");
			return Results.Ok(category);
		}

		public async Task<IResult> UpdateCategory(int id, CategoryRequest request)
		{
			var category = await context.Categories.FirstOrDefaultAsync(c => c.Id == id);
			if(category is null)
			{
				return Results.NotFound("No category with this id");
			}
			category.Update(request);
			await context.SaveChangesAsync();
			return Results.Ok(category);
		}
	}
}
