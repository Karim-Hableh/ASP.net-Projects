﻿using HomeWork_3.Data;
using HomeWork_3.Models;
using HomeWork_3.Requests;
using HomeWork_3.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace HomeWork_3.Services.Implementations
{
	public class ProductService : IProductService
	{
		private readonly DataContext context;
        public ProductService(DataContext context)
        {
            this.context = context;
        }
        public async Task<IResult> AddProduct(ProductRequest request)
		{
			var product = new Product
			{
				Name = request.Name,
				Description = request.Description,
				Price = request.Price,
				CategoryId = request.CategoryId,
			};
			context.Add(product);
			await context.SaveChangesAsync();
			return Results.Ok(product);
		}

		public async Task<IResult> DeleteProduct(int id)
		{
			var product = await context.Products.FirstOrDefaultAsync(p => p.Id == id);
			if (product is null)
			{
				return Results.NotFound("Product with this id does not exist");
			}
			context.Remove(product);
			await context.SaveChangesAsync();
			return Results.Ok("The product was successfully deleted");
		}

		public async Task<IResult> GetAllProducts(GetProductsParams input)
		{
			var query = context.Products.Include(p => p.Category).AsQueryable();
			if(input.MinPrice is not null)
			{
				query = query.Where(p => p.Price >= input.MinPrice);
			}
			if(input.MaxPrice is not null)
			{
				query = query.Where(p => p.Price <= input.MaxPrice);
			}
			if(input.ProductName is not null)
			{
				query = query.Where(p => p.Name.Contains(input.ProductName));
			}
			if(input.ProductDescription is not null)
			{
				query = query.Where(p => p.Description.Contains(input.ProductDescription));
			}
			if(input.CategoryId is not null)
			{
				query = query.Where(p => p.CategoryId == input.CategoryId);
			}
			var products = await query.ToListAsync();
			return Results.Ok(products);
		}

		public IResult GetAverage()
		{
			if(!context.Products.Any())
			{
				return Results.Ok(0);
			}
			var average = context.Products.Average(p => p.Price);
			return Results.Ok(average);
		}

		public async Task<IResult> GetProductById(int id)
		{
			var product = await context.Products.FirstOrDefaultAsync(p => p.Id == id);
			if(product is null)
			{
				return Results.NotFound("Product with this id does not exist");
			}
			return Results.Ok(product);
		}

		public async Task<IResult> UpdateProduct(int id, ProductRequest request)
		{
			var product = await context.Products.FirstOrDefaultAsync(p => p.Id == id);
			if (product is null)
			{
				return Results.NotFound("Product with this id does not exist");
			}
			product.Update(request);
			await context.SaveChangesAsync();
			return Results.Ok(product);
		}
		
	}
}
